You can upload one or severeal files with parameters values. 

<a href="https://www.dropbox.com/s/w7kow7ekdvpzkbi/Parameters%20Upload%20Template.xlsx?dl=1" target="_blank">Dowload a template of this file.</a>