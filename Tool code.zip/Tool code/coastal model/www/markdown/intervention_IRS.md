There are two opportunities to increase/decrease the IRS programme. 

If you wish to scale the programme once only (e.g. scale up in 2024 to 70% coverage), set the second coverage to the same level.
