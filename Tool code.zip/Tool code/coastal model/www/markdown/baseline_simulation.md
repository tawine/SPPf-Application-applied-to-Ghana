Adjust the transmission level for Pf and 'Simulate Baseline'.
The optimal value will minimise the sum of squares of the residuals between the API line and the reported incidence curve. 

Run as many time as needed for various values of the transmission level of Pf parameter.
Once the calibration is validated, you will be able to create package of interventions.