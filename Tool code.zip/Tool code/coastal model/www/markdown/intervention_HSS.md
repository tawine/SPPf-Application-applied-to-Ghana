There are two opportunities to increase/decrease access/effectiveness of the Health  System. 


If you wish to scale the programme once only (e.g. scale up treatment seeking in 2024 to 70% coverage), set the second coverage to the same level.

