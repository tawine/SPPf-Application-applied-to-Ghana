***

The [Modelling and Simulation Hub, Africa (MASHA)](http://www.masha.uct.ac.za) is a research group at the University of Cape Town.  MASHA’s research focus is the development and application of mathematical modelling and computer simulation to predict the dynamics and control of infectious diseases to evaluate the impact of policies aimed at reducing morbidity and mortality. Based in the Faculty of Science, MASHA’s research is closely integrated with other disciplines resulting in policy-driven and impactful scientific research. 
