Explore Results from Previous Session
(no sensitivity analysis data)